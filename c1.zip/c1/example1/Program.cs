﻿// Написание программы нахождения большего из двух чисел
Console.WriteLine("Задайте значение переменным a и b: ");
Console.WriteLine("Введите a: ");
int a = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите b: ");
int b = Convert.ToInt32(Console.ReadLine());
int max = 0;
if (a>b)
{
    max = a;
    Console.Write("Большее значение" );
    Console.WriteLine(max);
}
else {
    max = b;
    Console.Write("Большее значение: ");
    Console.WriteLine(max);
}
