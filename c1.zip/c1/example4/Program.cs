﻿// Отображение всеъ чётных чисел из N

Console.WriteLine("Введите количество перменных N: ");
int num = Convert.ToInt32(Console.ReadLine());
int current = 1;


Console.WriteLine("Все чётные числа: ");
while (current <= num){
    if (current % 2 == 0)
    Console.WriteLine(current);
    current++;
}


